import { config } from 'dotenv';
config();

import '@/ai/flows/filter-damage-images.ts';